# Krishna Code Review — Phase-wise UI Development Prompt

Use these prompts in order when developing or extending this interface. The UI is built in the currently selected workspace; the n8n workflow connection is intentionally pending until the GitHub Code Reviewer workflow and webhook URL are available.

## Phase 1 — Brand and visual foundation

> Create a polished, responsive web experience named **Krishna Code Review** for engineering teams. Use a confident navy, indigo, and teal palette; a compact Krishna “K” mark; modern readable typography; a professional sticky header and footer; and a calm, light workspace with subtle gradients and restrained motion. Keep the visual hierarchy clear and avoid clutter. Include desktop, tablet, and mobile layouts, accessible contrast, keyboard focus, and reduced-motion support.

**Verify:** The brand and page hierarchy are clear; navigation and panels remain usable at narrow viewport widths; keyboard focus is visible.

## Phase 2 — Review input and initial result experience

> Add the main review workspace. Let the user enter a GitHub pull request URL and submit it with a clear primary action. Show the review output beside the input on wide screens and below it on small screens. Start with a useful empty state explaining what to enter. Do not invent extra review options or claim a workflow is connected.

**Verify:** The URL field is labeled, the empty state is understandable, and the workspace rearranges cleanly on mobile.

## Phase 3 — Validation and interaction states

> Make the form interactive. Validate that the input is a valid HTTPS GitHub pull request URL (`github.com/{owner}/{repo}/pull/{number}`). Provide specific inline validation, a visible in-progress state, a success state that displays returned review text safely as text, and a recoverable error state for failed requests or empty responses. Disable duplicate submissions while a request is running, preserve the entered URL after failures, and announce state changes accessibly.

**Verify:** Submit an empty value and an invalid URL; both should show actionable errors. Simulate a request in progress, a successful response, an HTTP failure, and a network failure. Confirm review text is not interpreted as HTML.

## Phase 4 — n8n webhook connection and end-to-end verification

> After the intended GitHub Code Reviewer n8n workflow is identified, add a Webhook node before the existing review logic and a Respond to Webhook node after it. Preserve the existing review logic and credentials. Configure the webhook to accept `POST` JSON `{ "pullRequestUrl": "https://github.com/{owner}/{repo}/pull/{number}" }`, then return a JSON response containing review text, preferably `{ "review": "..." }`. Configure the frontend webhook URL without placing credentials in browser code. Set the required CORS origin and response headers for the deployed UI, then verify the entire flow using a real pull request that the configured GitHub credentials can access.

**Verify:** The frontend sends exactly one JSON `POST`; the workflow completes with a readable review; loading ends on both success and failure; and unauthenticated or inaccessible pull requests produce a clear error.
