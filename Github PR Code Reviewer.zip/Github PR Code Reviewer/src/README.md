# Krishna Code Review UI

A no-build, responsive frontend for a GitHub pull request review workflow. It uses plain HTML, CSS, and JavaScript so it can be previewed without installing dependencies.

## Run locally

From this folder, run:

```powershell
python -m http.server 8000
```

Then open `http://localhost:8000`.

## Configure the n8n endpoint

When the GitHub Code Reviewer workflow is ready, set `webhookUrl` in [config.js](./config.js) to its production Webhook URL. The UI sends:

```json
{
  "pullRequestUrl": "https://github.com/owner/repository/pull/42"
}
```

The UI displays review text from a plain-text response or common JSON fields such as `review`, `output`, `text`, or `response`. The recommended n8n response is JSON: `{ "review": "..." }`.

The intended workflow should begin with a `POST` Webhook node and end with a Respond to Webhook node after the existing review logic. Configure n8n CORS for the UI's origin before browser-based testing. Do not put GitHub credentials or other secrets in frontend files.

The local n8n instance available during this implementation contained only two unrelated, generically named workflows. No existing GitHub Code Reviewer workflow was changed. See [UI_DEVELOPMENT_PROMPT.md](./UI_DEVELOPMENT_PROMPT.md) for the phase-wise development and integration prompts.
