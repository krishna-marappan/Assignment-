window.KRISHNA_REVIEW_CONFIG = {
  webhookUrl: "http://localhost:5678/webhook-test/github-pr-review"
};
