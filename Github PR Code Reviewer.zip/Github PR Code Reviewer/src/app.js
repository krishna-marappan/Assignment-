
(() => {
  const form = document.querySelector("#review-form");
  const input = document.querySelector("#pull-request-url");
  const fieldError = document.querySelector("#url-error");
  const submitButton = document.querySelector("#submit-button");
  const buttonLabel = submitButton.querySelector(".button-label");

  const resultBody = document.querySelector("#result-body");
  const resultBadge = document.querySelector("#result-badge");
  const resultStatus = document.querySelector("#result-status");

  const connectionStatus = document.querySelector(".header-status");
  const connectionLabel = document.querySelector("#connection-label");

  const emptyState = document.querySelector("#empty-state");
  const loadingState = document.querySelector("#loading-state");
  const messageState = document.querySelector("#message-state");

  const messageIcon = document.querySelector("#message-icon");
  const messageTitle = document.querySelector("#message-title");
  const messageCopy = document.querySelector("#message-copy");

  const reviewResult = document.querySelector("#review-result");
  const reviewContent = document.querySelector("#review-content");
  const reviewedUrl = document.querySelector("#reviewed-url");

  const copyButton = document.querySelector("#copy-button");

  const webhookUrl =
    window.KRISHNA_REVIEW_CONFIG?.webhookUrl?.trim() || "";

  // Check whether a webhook URL is configured.
  if (webhookUrl) {
    connectionLabel.textContent = "Workflow endpoint configured";
  } else {
    connectionLabel.textContent = "Workflow setup pending";
  }

  // Update result badge.
  function setBadge(state, label) {
    resultBadge.className = `result-badge ${state}`;
    resultStatus.textContent = label;
  }

  // Display input validation errors.
  function setFieldError(message) {
    input.setAttribute("aria-invalid", message ? "true" : "false");
    fieldError.textContent = message;
    fieldError.hidden = !message;
  }

  // Switch between UI states.
  function showState(state) {
    emptyState.hidden = state !== "empty";
    loadingState.hidden = state !== "loading";
    messageState.hidden = state !== "message";
    reviewResult.hidden = state !== "result";

    resultBody.setAttribute(
      "aria-busy",
      state === "loading" ? "true" : "false"
    );
  }

  // Display success or error messages.
  function showMessage(title, copy, kind = "error") {
    showState("message");

    messageState.className = `message-state ${kind}`;
    messageIcon.textContent = kind === "success" ? "✓" : "!";
    messageTitle.textContent = title;
    messageCopy.textContent = copy;

    setBadge(
      kind === "success" ? "success" : "error",
      kind === "success" ? "Complete" : "Needs attention"
    );
  }

  // Validate GitHub Pull Request URL.
  function isPullRequestUrl(value) {
    try {
      const url = new URL(value);

      return (
        url.protocol === "https:" &&
        url.hostname.toLowerCase() === "github.com" &&
        /^\/[^/]+\/[^/]+\/pull\/\d+\/?$/.test(url.pathname)
      );
    } catch {
      return false;
    }
  }

  // Extract review text from n8n JSON response.
  function getReviewText(value, depth = 0) {
    if (depth > 6 || value == null) return "";

    if (typeof value === "string") {
      return value.trim();
    }

    if (Array.isArray(value)) {
      return value
        .map(item => getReviewText(item, depth + 1))
        .filter(Boolean)
        .join("\n\n");
    }

    if (typeof value !== "object") {
      return "";
    }

    const keys = [
      "review",
      "output",
      "text",
      "response",
      "result",
      "error",
      "message",
      "data"
    ];

    for (const key of keys) {
      if (key in value) {
        const text = getReviewText(value[key], depth + 1);

        if (text) return text;
      }
    }

    return "";
  }

  // Read response from n8n.
  async function readResponse(response) {
    const raw = await response.text();

    if (!raw.trim()) {
      return {
        review: "",
        status: ""
      };
    }

    try {
      const parsed = JSON.parse(raw);

      return {
        review:
          getReviewText(parsed) ||
          JSON.stringify(parsed, null, 2),
        status: parsed?.status || ""
      };
    } catch {
      return {
        review: raw.trim(),
        status: ""
      };
    }
  }

  // Submit GitHub Pull Request URL.
  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    setFieldError("");

    const pullRequestUrl = input.value.trim();

    if (!pullRequestUrl) {
      setFieldError(
        "Enter a GitHub pull request URL to start a review."
      );

      input.focus();
      return;
    }

    if (!isPullRequestUrl(pullRequestUrl)) {
      setFieldError(
        "Use a valid GitHub PR URL, such as https://github.com/org/repo/pull/42."
      );

      input.focus();
      return;
    }

    if (!webhookUrl) {
      showMessage(
        "Review workflow not connected",
        "Configure your n8n webhook URL in config.js before submitting."
      );

      return;
    }

    // Start loading state.
    submitButton.disabled = true;
    submitButton.classList.add("is-loading");

    buttonLabel.textContent = "Reviewing pull request…";
    input.disabled = true;

    showState("loading");
    setBadge("loading", "In progress");

    try {
      // Send PR URL to n8n.
      const response = await fetch(webhookUrl, {
        method: "POST",

        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json, text/plain"
        },

        body: JSON.stringify({
          pullRequestUrl: pullRequestUrl
        })
      });

      // Read n8n response.
      const result = await readResponse(response);

      if (!response.ok) {
        throw new Error(
          result.review ||
          `Workflow returned HTTP ${response.status}.`
        );
      }

      if (result.status === "error") {
        throw new Error(
          result.review || "The workflow reported an error."
        );
      }

      if (!result.review) {
        throw new Error(
          "The workflow completed without returning review results."
        );
      }

      // Display AI review results.
      reviewContent.textContent = result.review;
      reviewedUrl.textContent = pullRequestUrl;

      showState("result");
      setBadge("success", "Complete");

      connectionLabel.textContent = "Review workflow responded";

      connectionStatus.classList.add("connected");

    } catch (error) {
      console.error("Review workflow error:", error);

      const isNetworkError =
        error instanceof TypeError;

      const errorMessage = isNetworkError
        ? "We couldn't reach n8n. Check that your workflow is listening or published, and verify the webhook URL and CORS settings."
        : error instanceof Error
          ? error.message
          : "Something went wrong while reviewing this pull request.";

      showMessage(
        "We couldn't complete the review",
        errorMessage
      );

    } finally {
      // Restore form controls.
      submitButton.disabled = false;
      submitButton.classList.remove("is-loading");

      buttonLabel.textContent = "Review pull request";
      input.disabled = false;
    }
  });

  // Copy AI review results.
  copyButton.addEventListener("click", async () => {
    const originalLabel = "Copy review";

    try {
      await navigator.clipboard.writeText(
        reviewContent.textContent
      );

      copyButton.lastChild.textContent = " Copied";

      window.setTimeout(() => {
        copyButton.lastChild.textContent = ` ${originalLabel}`;
      }, 1600);

    } catch (error) {
      showMessage(
        "Unable to copy review",
        "Select the review text and copy it manually."
      );
    }
  });

})();
